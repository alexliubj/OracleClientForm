using System;
using System.Collections.Generic;
using System.Linq;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Audio;
using Microsoft.Xna.Framework.Content;
using Microsoft.Xna.Framework.GamerServices;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework.Input;
using Microsoft.Xna.Framework.Media;


namespace FinalProject
{
    /// <summary>
    /// This is a game component that implements IUpdateable.
    /// </summary>
    public class gc_SplashScreen : DrawableGameComponent
    {
        SpriteBatch spriteBatch;
        Texture2D clouds;
        float offsetX = -10, speed=1.5f;
        Vector2 position = new Vector2();
        int cloudWidth, screenWidth;

        public gc_SplashScreen(Game game)
            : base(game)
        {
            // TODO: Construct any child components here
        }

        /// <summary>
        /// Allows the game component to perform any initialization it needs to before starting
        /// to run.  This is where it can query for any required services and load content.
        /// </summary>
        public override void Initialize()
        {
            // TODO: Add your initialization code here

            base.Initialize();
        }

        /// <summary>
        /// Allows the game component to update itself.
        /// </summary>
        /// <param name="gameTime">Provides a snapshot of timing values.</param>
        public override void Update(GameTime gameTime)
        {
            // TODO: Add your update code here
            if (Keyboard.GetState().IsKeyDown(Keys.Space)) ((Game1)Game).ShowMenu();
            position.X += speed;
            if (position.X > 0)
                position.X -= cloudWidth;
            base.Update(gameTime);
        }
        public override void Draw(GameTime gameTime)
        {
            spriteBatch.Begin();
            //start beyond left of screen and keep drawing until 
            //the right is beyond the right of the screen
            float currentLeft = position.X;
            while (currentLeft < screenWidth)
            {
                spriteBatch.Draw(clouds, new Vector2(currentLeft, 0), Color.White);
                currentLeft += cloudWidth;
            }
            spriteBatch.End();
            base.Draw(gameTime);
        }
        protected override void LoadContent()
        {
            spriteBatch = new SpriteBatch(Game.GraphicsDevice);
            clouds = Game.Content.Load<Texture2D>(@"Sprites/clouds");
            cloudWidth = clouds.Width;
            screenWidth = Game.GraphicsDevice.Viewport.Bounds.Width;
            base.LoadContent();
        }
    }
}
