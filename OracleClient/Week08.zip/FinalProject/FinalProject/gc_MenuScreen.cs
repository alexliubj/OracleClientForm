using System;
using System.Collections.Generic;
using System.Linq;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Audio;
using Microsoft.Xna.Framework.Content;
using Microsoft.Xna.Framework.GamerServices;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework.Input;
using Microsoft.Xna.Framework.Media;


namespace FinalProject
{
    /// <summary>
    /// This is a game component that implements IUpdateable.
    /// </summary>
    public class gc_MenuScreen : DrawableGameComponent
    {
        private string menuTitle = "Menu";
        float lineHeight = 50;
        private string[] menuItems;
        private int selectedIndex;
        SpriteFont largeFont, smallFont;
        Color selectColor = Color.Gold, normalColor = Color.White;
        KeyboardState oldKeystate = Keyboard.GetState();
        SpriteBatch spriteBatch;
        
        public void SetMenuItem(string[] items)
        {
            menuItems = items;
        }
        public gc_MenuScreen(Game game)
            : base(game)
        {
            // TODO: Construct any child components here
        }

        /// <summary>
        /// Allows the game component to perform any initialization it needs to before starting
        /// to run.  This is where it can query for any required services and load content.
        /// </summary>
        public override void Initialize()
        {
            // TODO: Add your initialization code here

            base.Initialize();
        }

        /// <summary>
        /// Allows the game component to update itself.
        /// </summary>
        /// <param name="gameTime">Provides a snapshot of timing values.</param>
        public override void Update(GameTime gameTime)
        {
            // TODO: Add your update code here
            KeyboardState newKeystate = Keyboard.GetState();
            if (oldKeystate.IsKeyUp(Keys.Up) && newKeystate.IsKeyDown(Keys.Up))
            {
                selectedIndex--;
                if (selectedIndex < 0) selectedIndex = menuItems.Length - 1;
            }
            if (oldKeystate.IsKeyUp(Keys.Down) && newKeystate.IsKeyDown(Keys.Down))
            {
                selectedIndex++;
                if (selectedIndex == menuItems.Length ) selectedIndex = 0;
            }
            if (newKeystate.IsKeyDown(Keys.Enter))
            {
                if (menuItems[selectedIndex] == "3D Demo")
                {
                    ((Game1)Game).ShowShipDemo();
                }
            }
            oldKeystate = newKeystate;
            base.Update(gameTime);
        }
        protected override void LoadContent()
        {
            spriteBatch = new SpriteBatch(GraphicsDevice);
            smallFont = Game.Content.Load<SpriteFont>(@"Fonts\smallFont");
            largeFont = Game.Content.Load<SpriteFont>(@"Fonts\largeFont");
            base.LoadContent();
        }
        public override void Draw(GameTime gameTime)
        {
            spriteBatch.Begin();
            Vector2 currentPosition=new Vector2(100, 50);
            spriteBatch.DrawString(largeFont, menuTitle, currentPosition, normalColor);
            for (int i = 0; i < menuItems.Length; i++)
            {
                currentPosition.Y += lineHeight;
                if (i == selectedIndex)
                {
                    spriteBatch.DrawString(smallFont, menuItems[i], currentPosition, selectColor);
                }
                else
                {
                    spriteBatch.DrawString(smallFont, menuItems[i], currentPosition, normalColor);
                }
                
            }
            spriteBatch.End();
            base.Draw(gameTime);
        }
    }
}
